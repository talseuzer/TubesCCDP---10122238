package structural;

import java.util.ArrayList;
import java.util.List;

public class BatikBundle implements ProductComponent {
    private String bundleName;
    private List<ProductComponent> components = new ArrayList<>();

    public BatikBundle(String bundleName) { this.bundleName = bundleName; }

    public void addComponent(ProductComponent pc) { components.add(pc); }

    public double getPrice() {
        return components.stream().mapToDouble(ProductComponent::getPrice).sum();
    }

    public String getName() { return bundleName; }

    public void printDetails() {
        System.out.println("Paket: " + bundleName + " (Total: Rp" + getPrice() + ")");
        for (ProductComponent pc : components) {
            pc.printDetails();
        }
    }
}