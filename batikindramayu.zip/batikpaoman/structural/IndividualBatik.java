package structural;

public class IndividualBatik implements ProductComponent {
    private String name;
    private double price;

    public IndividualBatik(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public double getPrice() { return price; }
    public String getName() { return name; }
    public void printDetails() {
        System.out.println("- " + name + ": Rp" + price);
    }
}
