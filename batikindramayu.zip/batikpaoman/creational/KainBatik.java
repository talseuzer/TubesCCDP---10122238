package creational;

public class KainBatik implements BatikPrototype {
    private String motif;
    private String warna;

    public KainBatik(String motif, String warna) {
        this.motif = motif;
        this.warna = warna;
    }

    @Override
    public BatikPrototype clone() {
        return new KainBatik(this.motif, this.warna);
    }

    @Override
    public void setWarna(String warna) { this.warna = warna; }

    @Override
    public void display() {
        System.out.println("Kain Batik [Motif: " + motif + ", Warna: " + warna + "]");
    }
}