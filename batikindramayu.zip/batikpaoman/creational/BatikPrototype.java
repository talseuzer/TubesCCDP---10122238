package creational;

public interface BatikPrototype {
    BatikPrototype clone();
    void setWarna(String warna);
    void display();
}