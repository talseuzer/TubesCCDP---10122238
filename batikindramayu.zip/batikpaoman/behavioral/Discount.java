package behavioral;

public class Discount implements DiscountStrategy {
    @Override
    public double applyDiscount(double price) {
        return price * 0.83; 
    }
}