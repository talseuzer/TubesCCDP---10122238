package behavioral;

import structural.ProductComponent;

public class Transaction {
    private ProductComponent product;
    private DiscountStrategy strategy;

    public Transaction(ProductComponent product) {
        this.product = product;
        this.strategy = new NormalPrice();
    }

    public void setStrategy(DiscountStrategy strategy) { this.strategy = strategy; }

    public void printInvoice() {
        double finalPrice = strategy.applyDiscount(product.getPrice());
        System.out.println("=== INVOICE BATIK INDRAMAYU ===");
        product.printDetails();
        System.out.println("Harga Akhir: Rp" + finalPrice);
        System.out.println("============================\n");
    }
}
