package behavioral;

public interface DiscountStrategy {
    double applyDiscount(double price);
}