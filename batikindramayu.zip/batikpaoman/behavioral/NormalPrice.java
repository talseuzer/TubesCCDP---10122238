package behavioral;

public class NormalPrice implements DiscountStrategy {
    @Override
    public double applyDiscount(double price) {
        return price;
    }
}