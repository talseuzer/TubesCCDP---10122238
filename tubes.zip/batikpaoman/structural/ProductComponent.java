package structural;

public interface ProductComponent {
    String getName();
    double getPrice();
    void printDetails();
}
