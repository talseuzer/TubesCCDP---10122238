import creational.*;
import structural.*;
import behavioral.*;

public class Main {
    public static void main(String[] args) {
        KainBatik masterKapalKandas = new KainBatik("Kapal Kandas", "Sogan");
        KainBatik varianBiru = (KainBatik) masterKapalKandas.clone();
        varianBiru.setWarna("Pesisir Biru");

        System.out.println("=== DEMO PROTOTYPE PATTERN ===");
        masterKapalKandas.display();
        varianBiru.display();
        System.out.println("============================\n");

        IndividualBatik kain1 = new IndividualBatik("Kain Etong", 250000);
        IndividualBatik kain2 = new IndividualBatik("Syal Ganggeng", 100000);
        
        BatikBundle paketHantaran = new BatikBundle("Paket Seserahan Dermayu");
        paketHantaran.addComponent(kain1);
        paketHantaran.addComponent(kain2);

        Transaction trans1 = new Transaction(paketHantaran);
        
        System.out.println("Harga Normal:");
        trans1.printInvoice();

        System.out.println("Harga Promo HUT Indramayu:");
        trans1.setStrategy(new Discount());
        trans1.printInvoice();
    }
}